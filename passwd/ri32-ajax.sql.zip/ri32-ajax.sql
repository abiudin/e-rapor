-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Feb 09, 2010 at 02:02 AM
-- Server version: 5.0.41
-- PHP Version: 4.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `ri32-ajax`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `t_fakultas`
-- 

CREATE TABLE `t_fakultas` (
  `id_fak` int(2) NOT NULL auto_increment,
  `nama_fak` varchar(30) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_fak`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `t_fakultas`
-- 

INSERT INTO `t_fakultas` VALUES (1, 'Ilmu Komputer');
INSERT INTO `t_fakultas` VALUES (2, 'Teknologi Industri');
INSERT INTO `t_fakultas` VALUES (3, 'Ekonomi');
INSERT INTO `t_fakultas` VALUES (4, 'Teknik Sipil');

-- --------------------------------------------------------

-- 
-- Table structure for table `t_jurusan`
-- 

CREATE TABLE `t_jurusan` (
  `id_jur` int(2) NOT NULL auto_increment,
  `id_fak` int(2) NOT NULL,
  `nama_jur` varchar(30) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_jur`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=11 ;

-- 
-- Dumping data for table `t_jurusan`
-- 

INSERT INTO `t_jurusan` VALUES (1, 1, 'Sistem Informasi');
INSERT INTO `t_jurusan` VALUES (2, 1, 'Sistem Komputer');
INSERT INTO `t_jurusan` VALUES (3, 2, 'Teknik Informatika');
INSERT INTO `t_jurusan` VALUES (4, 2, 'Teknik Elektro');
INSERT INTO `t_jurusan` VALUES (5, 2, 'Teknik Mesin');
INSERT INTO `t_jurusan` VALUES (6, 2, 'Teknik Industri');
INSERT INTO `t_jurusan` VALUES (7, 3, 'Akuntansi');
INSERT INTO `t_jurusan` VALUES (8, 3, 'Manajemen');
INSERT INTO `t_jurusan` VALUES (9, 4, 'Teknik Arsitektur');
INSERT INTO `t_jurusan` VALUES (10, 4, 'Teknik Sipil');
